function phi_matrix = phi_function_large(v, d, q)
% phi_function_large - Memory-efficient phi function for long sequences.
%
% Inputs:
%   v - Input sequence (vector)
%   d - Number of output dimensions (columns)
%   q - Step size between elements
%
% Output:
%   phi_matrix - Resulting matrix of shape (m, d)

    % Ensure v is a column vector
    v = v(:);  

    r = length(v);
    m = 1 + floor((r - d) / q);  % Number of rows

    % Preallocate output matrix
    phi_matrix = zeros(m, d, 'single');  % Use 'single' to save memory

    % Fill matrix column by column
    for i = 1:d
        start_idx = i;
        stop_idx = i + (r - d);
        phi_matrix(:, i) = v(start_idx:q:stop_idx);
    end
end
