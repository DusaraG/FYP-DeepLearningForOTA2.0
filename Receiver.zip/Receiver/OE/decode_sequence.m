function decoded_frames = decode_sequence(IQ_samples, N, Nseq, Nmsg, OE_model, sd_model)
% Decode a continuous sequence of IQ samples into decoded frames.
%
% Inputs:
%   IQ_samples - Vector of IQ samples
%   N          - Number of samples per frame
%   Nseq       - Number of input sequences for SD model
%   Nmsg       - Samples per message
%   OE_model   - Offset estimator model
%   sd_model   - Frame decoder model
%
% Output:
%   decoded_frames - Cell array of decoded frame outputs

    i = 1;  % Start index (MATLAB is 1-based)
    b = 0;  % Frame counter
    decoded_frames = {};
    total_samples = numel(IQ_samples);
    
    fprintf('Total samples are %d\n', total_samples);

    while (i + N - 1) <= total_samples
        % Reshape block into (Nseq x N)
        if (i + Nseq * N - 1) > total_samples
            break;
        end
        batch_Y = reshape(IQ_samples(i : i + Nseq * N - 1), [N, Nseq])';

        fprintf('Batch shape: [%d x %d]\n', size(batch_Y,1), size(batch_Y,2));

        % Estimate offset (transpose to match shape m x N)
        offset = estimate_offset(batch_Y, Nmsg, OE_model);
        fprintf('Offset: %.2f\n', offset);

        % Adjust index based on estimated offset
        i_b = i + round(offset);

        if (i_b + N - 1) > total_samples
            break;
        end

        % Prepare input for SD model (1 x Nseq)
        frame_samples = reshape(IQ_samples(i_b : i_b + Nseq - 1), 1, Nseq);

        % Decode frame
        decoded_frame = decode_frame(frame_samples, sd_model);
        decoded_frames{end+1} = decoded_frame;

        % Update index
        i = i_b + N - 2 * b * Nmsg;
        b = b + 1;
    end
end
