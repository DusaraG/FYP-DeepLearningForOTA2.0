function [X, Y] = generateCircularShiftedData(samples, Nseq)
% samples: 1D array of IQ samples
% Nseq: Number of samples per frame (e.g., 416)

    samples = reshape(samples, [], 1); % Ensure column vector
    total_samples = numel(samples);
    num_frames = ceil(total_samples / Nseq);

    % Pad if necessary
    if num_frames * Nseq > total_samples
        padding_amount = num_frames * Nseq - total_samples;
        samples = [samples; zeros(padding_amount, 1)];
    end

    % Reshape into frames
    frames = reshape(samples, Nseq, num_frames)';  % num_frames x Nseq

    offsets = -8:7; % total 16
    one_hot_labels = eye(16); % Identity matrix for one-hot

    X = [];
    Y = [];

    for i = 1:num_frames
        frame = frames(i, :);
        for j = 1:length(offsets)
            shifted = circshift(frame, offsets(j), 2);
            X = [X; shifted];
            Y = [Y; one_hot_labels(j,:)];  % Offset + 8 indexing
        end
    end
end
