% function layers = buildOffsetEstimatorModel(N_seq, num_classes)
%     % Create layer graph for the OffsetEstimator model
%     classLabels = categorical(-7:8); 
%     layers = [
%         featureInputLayer(N_seq, 'Name', 'OE_input', 'Normalization','none')
% 
%         fullyConnectedLayer(256, 'Name', 'dense_layer_1')
%         reluLayer('Name', 'relu_1')
% 
%         fullyConnectedLayer(256, 'Name', 'dense_layer_2')
%         reluLayer('Name', 'relu_2')
% 
%         fullyConnectedLayer(256, 'Name', 'dense_layer_3')
%         reluLayer('Name', 'relu_3')
% 
%         fullyConnectedLayer(num_classes, 'Name', 'output_layer')
%         softmaxLayer('Name', 'softmax')
% 
%         classificationLayer('Name', 'class_output','Classes', classLabels)
%     ];
% end

function layers = buildOffsetEstimatorModel(N_seq, num_classes)
    % Define dummy weights and biases
    W1 = randn([256, N_seq]);
    b1 = randn([256, 1]);

    W2 = randn([256, 256]);
    b2 = randn([256, 1]);

    W3 = randn([256, 256]);
    b3 = randn([256, 1]);

    Wout = randn([num_classes, 256]);
    bout = randn([num_classes, 1]);

    % Define class labels from -7 to 8
    classLabels = categorical(-7:8);

    % Create layer array with weights and biases
    layers = [
        featureInputLayer(N_seq, 'Name', 'OE_input', 'Normalization','none')

        fullyConnectedLayer(256, 'Name', 'dense_layer_1', 'Weights', W1, 'Bias', b1)
        reluLayer('Name', 'relu_1')

        fullyConnectedLayer(256, 'Name', 'dense_layer_2', 'Weights', W2, 'Bias', b2)
        reluLayer('Name', 'relu_2')

        fullyConnectedLayer(256, 'Name', 'dense_layer_3', 'Weights', W3, 'Bias', b3)
        reluLayer('Name', 'relu_3')

        fullyConnectedLayer(num_classes, 'Name', 'output_layer', 'Weights', Wout, 'Bias', bout)
        softmaxLayer('Name', 'softmax')

        classificationLayer('Name', 'class_output', 'Classes', classLabels)
    ];
end

