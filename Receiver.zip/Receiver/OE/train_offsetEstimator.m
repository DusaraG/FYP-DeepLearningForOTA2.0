% Set hyperparameters
N_seq = 416;
num_classes = 16;

% Load your training, validation, and test data
% Assume train_ds, val_ds, and test_ds are datastores or tables
% with predictors as numeric arrays and responses as categorical labels

% Convert table to datastore (if needed)
% train_ds = arrayDatastore(train_features, 'IterationDimension', 1);
% val_ds = arrayDatastore(val_features, 'IterationDimension', 1);

% Build model
layers = buildOffsetEstimatorModel(N_seq, num_classes);

% Define training options
options = trainingOptions('adam', ...
    'MaxEpochs', 10, ...
    'MiniBatchSize', 32, ...
    'Shuffle','every-epoch', ...
    'ValidationData', val_ds, ...
    'ValidationFrequency', 20, ...
    'Verbose', true, ...
    'Plots','training-progress');

% Train model
model = trainNetwork(train_ds, layers, options);
