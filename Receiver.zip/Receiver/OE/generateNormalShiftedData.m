function [X, Y] = generateNormalShiftedData(samples, Nseq)
% Generates training data by globally shifting the entire IQ sample array.
%
% Inputs:
%   samples - 1D array of IQ samples
%   Nseq    - Frame length (e.g., 416)
%
% Outputs:
%   X - Feature matrix of shape (num_samples, Nseq)
%   Y - One-hot encoded labels of shape (num_samples, 16)

    samples = reshape(samples, [], 1); % Ensure column vector
    total_samples = numel(samples);
    num_frames = ceil(total_samples / Nseq);

    offsets = -8:7;
    one_hot_labels = eye(16); % Identity matrix for one-hot labels

    X = [];
    Y = [];

    for k = 1:length(offsets)
        offset = offsets(k);

        % Shift entire sample sequence
        shifted_samples = circshift(samples, offset);

        % Pad if needed
        if num_frames * Nseq > numel(shifted_samples)
            padding_amount = num_frames * Nseq - numel(shifted_samples);
            shifted_samples = [shifted_samples; zeros(padding_amount, 1)];
        end

        % Reshape into frames
        frames = reshape(shifted_samples, Nseq, num_frames)';
        
        % Repeat label for all frames in this offset
        X = [X; frames];
        Y = [Y; repmat(one_hot_labels(k, :), num_frames, 1)];
    end
end