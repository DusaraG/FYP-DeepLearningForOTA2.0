function offset = estimate_offset(Y, Nmsg, OE_model)
% Estimate the sample offset from a batch of IQ-sample sequences.
%
% Inputs:
%   Y       - Input tensor (m x N_seq)
%   Nmsg    - Number of samples per message
%   OE_model - Offset estimator (a trained dlnetwork object)
%
% Output:
%   offset  - Estimated sample offset (scalar)

    m = size(Y,1); % Number of sequences

    % Predict offsets in batch using the OE model
    offset_tensor = predict(OE_model, dlarray(Y','CB'));  % Output: 16 x m
    offset_tensor = extractdata(offset_tensor)';  % Convert to m x 16

    % Perform tensor-based rolling (circular shift per row)
    rolled_offset = zeros(size(offset_tensor), 'like', offset_tensor);
    for i = 1:m
        rolled_offset(i,:) = circshift(offset_tensor(i,:), i-1, 2);
    end

    % Compute the mean over all sequences
    r = mean(rolled_offset, 1);  % 1 x 16

    % Find index of the maximum value
    [~, r_idx] = max(r);
    r_idx = single(r_idx - 1);  % zero-based index

    % Compute offset adjustment
    offset = r_idx - 1 - floor((r_idx - 1) / (Nmsg / 2));
end
