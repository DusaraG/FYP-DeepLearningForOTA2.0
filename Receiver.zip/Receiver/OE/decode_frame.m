function decoded_frame = decode_frame(Y, sd_model)
% Decode a frame using the SD neural network model.
%
% Inputs:
%   Y        - Frame input (1 x Nseq) or (Nseq x 1)
%   sd_model - Trained decoder model (dlnetwork)
%
% Output:
%   decoded_frame - Model prediction (class probabilities, etc.)

    % Convert to proper shape for model input
    if size(Y,1) ~= 1
        Y = Y';
    end

    decoded_frame = predict(sd_model, dlarray(Y,'CB'));
    decoded_frame = extractdata(decoded_frame);
end
