function image = reconstructionimage(rx, rxNet, OeNet)
%% reconstruction
display("OFFSET ESTIMOTOR model");
figure;
lgraph = layerGraph(OeNet); 
plot(lgraph)

display("Decoder model");
figure;
lgraph = layerGraph(OeNet);
plot(lgraph)

lgraph = layerGraph(rxNet);
plot(lgraph)

load("nn_param.mat");
phshdatapayload_image = 'rxModels/demomodels/nn%d_db%d_n%d_k_NLOS/phshdatapayload_image.csv';
phshdatapayload_image = sprintf(phshdatapayload_image,EbNo,n,k);

seqnum_image='rxModels/demomodels/nn%d_db%d_n%d_k_NLOS/seqnums_image.csv';
seqnum_image = sprintf(seqnum_image,EbNo,n,k);

decodephshdataNNfirstpahse
recover_color_imagefirstpahse
writematrix(phshdatapayload,phshdatapayload_image)
writematrix(mesrxdecodeNN(end,:),seqnum_image)

image = uint8(reconstructedImage);

