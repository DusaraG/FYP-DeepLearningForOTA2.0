function rx_sig = offset_estimation(rx, Net)
    
    lgraph = layerGraph(Net);
    plot(lgraph)
    rx_sig = rx;