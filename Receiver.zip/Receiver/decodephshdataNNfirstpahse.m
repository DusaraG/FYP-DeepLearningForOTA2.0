

load("phshdata")
% load("mesdata")
s = size(phshdata);
n_columns = s(2);%need to change

pQPSKDemodulator = comm.QPSKDemodulator('PhaseOffset',pi/4, ...
                'BitOutput', true);

mesrxdecodeNN=[];
phshdatapayload=[];
for i =(1:n_columns)

    thisFramedata = phshdata(22:end,i)*exp(1i*((2*pi)/360)*(0));
    thisFrameheader=phshdata(1:21,i);
    thisFrame=[thisFrameheader;thisFramedata];

    decoded_data = helperAEWDecode(thisFramedata,rxNet(1));
    decoded_headerbits = pQPSKDemodulator(thisFrameheader);
                 
    % deScrData = pDescrambler( ...
                    % decoded_bits(prmQPSKReceiver.HeaderLength + (1 : prmQPSKReceiver.PayloadLength)));

    % charSet = int8(bi2de(reshape(deScrData, 7, [])', 'left-msb'));
    % fprintf('%s', char(charSet));


    flag = bi2de(reshape(decoded_headerbits(26+13:end),4, [])', 'left-msb');
    seqnum = bit2int(decoded_headerbits(27:end-4),12);


    if 10<seqnum && seqnum < n_columns && flag<5 
    phshdatapayload=[phshdatapayload,thisFrame(22:end)];
    decoded_data = [decoded_data;seqnum];
    mesrxdecodeNN = [mesrxdecodeNN,decoded_data];
    end

end
save('mesrxdecodeNN.mat','mesrxdecodeNN');
% release(pDescrambler);
% release(pQPSKDemodulator);