function rxsignal = runRx(prmQPSKReceiver, printData, Th)
persistent qpskRx radio
if isempty(qpskRx)
    qpskRx = QPSKReceiver(...
        'ModulationOrder',                      prmQPSKReceiver.ModulationOrder, ...
        'SampleRate',                           prmQPSKReceiver.RTLFrontEndSampleRate, ...
        'DecimationFactor',                     prmQPSKReceiver.Decimation, ...
        'FrameSize',                            prmQPSKReceiver.FrameSize, ...
        'HeaderLength',                         prmQPSKReceiver.HeaderLength, ...
        'NumberOfMessage',                      prmQPSKReceiver.NumberOfMessage, ...
        'PayloadLength',                        prmQPSKReceiver.PayloadLength, ...
        'DesiredPower',                         prmQPSKReceiver.DesiredPower, ...
        'AveragingLength',                      prmQPSKReceiver.AveragingLength, ...
        'MaxPowerGain',                         prmQPSKReceiver.MaxPowerGain, ...
        'RolloffFactor',                        prmQPSKReceiver.RolloffFactor, ...
        'RaisedCosineFilterSpan',               prmQPSKReceiver.RaisedCosineFilterSpan, ...
        'InputSamplesPerSymbol',                prmQPSKReceiver.Interpolation, ...
        'MaximumFrequencyOffset',               prmQPSKReceiver.MaximumFrequencyOffset, ...
        'PostFilterOversampling',               prmQPSKReceiver.Interpolation/prmQPSKReceiver.Decimation, ...
        'PhaseRecoveryLoopBandwidth',           prmQPSKReceiver.PhaseRecoveryLoopBandwidth, ...
        'PhaseRecoveryDampingFactor',           prmQPSKReceiver.PhaseRecoveryDampingFactor, ...
        'TimingRecoveryDampingFactor',          prmQPSKReceiver.TimingRecoveryDampingFactor, ...
        'TimingRecoveryLoopBandwidth',          prmQPSKReceiver.TimingRecoveryLoopBandwidth, ...
        'TimingErrorDetectorGain',              prmQPSKReceiver.TimingErrorDetectorGain, ...
        'PreambleDetectorThreshold',            prmQPSKReceiver.PreambleDetectorThreshold, ...    
        'DescramblerBase',                      prmQPSKReceiver.ScramblerBase, ...
        'DescramblerPolynomial',                prmQPSKReceiver.ScramblerPolynomial, ...
        'DescramblerInitialConditions',         prmQPSKReceiver.ScramblerInitialConditions,...
        'CFCAlgorithm',                         prmQPSKReceiver.CFCAlgorithm, ...
        'PrintOption',                          printData);
    % 
    % Create and configure the RTL System object.
    radio = comm.SDRRTLReceiver('0','CenterFrequency',prmQPSKReceiver.RTLCenterFrequency,'SampleRate',prmQPSKReceiver.RTLFrontEndSampleRate, ...
    'SamplesPerFrame',prmQPSKReceiver.RTLFrameLength,'EnableTunerAGC',true,'OutputDataType','double');

    % 
    % radio = comm.SDRRTLReceiver('0','CenterFrequency',prmQPSKReceiver.RTLCenterFrequency,'SampleRate',prmQPSKReceiver.RTLFrontEndSampleRate, ...
    % 'SamplesPerFrame',prmQPSKReceiver.RTLFrameLength,'EnableTunerAGC',false,'OutputDataType','double','TunerGain',prmQPSKReceiver.RTLGain);
    
end


cleanupRx = onCleanup(@()release(qpskRx));
cleanupRadio = onCleanup(@()release(radio));

% Initialize variables
currentTime = zeros(1, 1);
overflow = uint32(0);
rxsignal=[];
filtered = [];
phshdata = [];
rxmes = [];
headerlis=[];
isTxActive = 0;
state = 1;%QPSK
i=0;
freqOffsetnew = 0;
freqOffsetEstlis=[];
PHESTlis={};
decodedseqnumlis=[];
flaglis=[];
statelis=[];
while currentTime < prmQPSKReceiver.StopTime

    [rcvdSignal_, ~, toverflow] = step(radio);
    % rcvdSignal=rcvdSignal_;

    THRE = 0.09;
    isLarge = abs(rcvdSignal_) > THRE;
    % rcvdSignal = isLarge    .* rcvdSignal_ + ~isLarge .* (1e-10i);
    rcvdSignal = rcvdSignal_;
    if sum(isLarge)
        isTxActive = 1;
    else
        isTxActive = 0;
    end
    
    if isTxActive
        i=i+1;
        fprintf('%s ',num2str(i));
        rxsignal=[rxsignal,rcvdSignal];

        if  (rem(i-113,110)==0)
         state = 1;
        end

        if ~toverflow % Avoid overflow frames for continuous-mode receiver synchronization
            [filteredsig, ~, ~,phShiftedData,charSet,isFrameValid,~,~,header,freqOffsetEst,PHEST,decodedseqnum,flag] = qpskRx(rcvdSignal,state,freqOffsetnew); % Receiver
            PHESTlis{i}=PHEST;
            filtered = [filtered,filteredsig];
            if isFrameValid
                decodedseqnumlis=[decodedseqnumlis,decodedseqnum];
                flaglis=[flaglis,flag];
                statelis=[statelis,state];
                headerlis=[headerlis,header];
                if   ((decodedseqnum < 8 && flag >12) || i<4)
                    freqOffsetEstlis=[freqOffsetEstlis,freqOffsetEst];
                    state = 1;
                else
                    state = 0;
                    freqOffsetnew = freqOffsetEstlis(end);
                end
                phshdata=[phshdata,phShiftedData];
                rxmes = [rxmes,charSet];
            else
                fprintf('\n');
            end
        end

    else
        i=0;
    end   

    overflow = toverflow + overflow;
    currentTime = currentTime + prmQPSKReceiver.RTLFrameTime;
end

save('phshdata.mat','phshdata');
save('rxmes.mat','rxmes');
save('rcvdSignal.mat','rxsignal');
save('flaglis.mat','flaglis');
save('decodedseqnumlis.mat','decodedseqnumlis');
save('statelis.mat','statelis');
save('PHESTlis.mat','PHESTlis');
save('freqOffsetEstlis.mat','freqOffsetEstlis');




