function thresh = thresholdFinding(config)

radio = config.radio;

Nsignal=[];
currentTime = 0;

% release(radio);
% % while currentTime < 100
% %      
% %     [rcvdSignal_, ~, ~] = step(radio);
% %     Nsignal=[Nsignal,rcvdSignal_];
% %     currentTime = currentTime + 1;
% % end
% % release(radio);
% % Compute the mean of the entire matrix
% mean_value = max(mean(Nsignal, 'all'));
% 
% % Compute the variance of the entire matrix
% variance_value = var(Nsignal(:));  % Convert to vector for overall variance
% 
% alpha = 7;
% TH_f = abs(mean_value) + alpha*sqrt(abs(variance_value));
% disp(["Threshold :",num2str(TH_f)]);
thresh = 0.09;%round(TH_f,2);

