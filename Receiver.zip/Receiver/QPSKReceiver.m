classdef (StrictDefaults)QPSKReceiver < matlab.System

    properties (Nontunable)
        ModulationOrder;
        SampleRate;
        DecimationFactor;
        FrameSize;
        HeaderLength;
        NumberOfMessage;
        PayloadLength;
        DesiredPower;
        AveragingLength;
        MaxPowerGain;
        RolloffFactor;
        RaisedCosineFilterSpan;
        InputSamplesPerSymbol;
        MaximumFrequencyOffset;
        FrequencyResolution = 1000;
        CFCAlgorithm;
        PostFilterOversampling;
        PhaseRecoveryLoopBandwidth;
        PhaseRecoveryDampingFactor;
        TimingRecoveryDampingFactor;
        TimingRecoveryLoopBandwidth;
        TimingErrorDetectorGain;
        PreambleDetectorThreshold;
        PreambleDetectorThreshold2;
        DescramblerBase;
        DescramblerPolynomial;
        DescramblerInitialConditions;
        PrintOption;
    end

    properties (Access = private)
        pAGC
        pRxFilter
        pCoarseFreqEstimator
        pCoarseFreqCompensator
        pFineFreqCompensator
        pTimingRec
        pPrbDet
        pPrbDet2
        pFrameSync
        pDataDecod
        pMeanFreqOff
        pModulatedHeader = sqrt(2)/2 * (-1-1i) * [+1; +1; +1; +1; +1; -1; -1; +1; +1; -1; +1; -1; +1];
        pHeader = [3;3;3;3;3;0;0;3;3;0;3;0;3];

        pCnt
    end

    properties (Access = private, Constant)
        pUpdatePeriod = 4 % Defines the size of vector that will be processed in AGC system object
    end

    methods
        function obj = QPSKReceiver(varargin)
            setProperties(obj,nargin,varargin{:});
        end
    end

    methods (Access = protected)
        function setupImpl(obj, ~)

            obj.pAGC = comm.AGC( ...
                'DesiredOutputPower',       obj.DesiredPower, ...
                'AveragingLength',          obj.AveragingLength, ...
                'MaxPowerGain',             obj.MaxPowerGain);

            obj.pRxFilter = comm.RaisedCosineReceiveFilter( ...
                'RolloffFactor',            obj.RolloffFactor, ...
                'FilterSpanInSymbols',      obj.RaisedCosineFilterSpan, ...
                'InputSamplesPerSymbol',    obj.InputSamplesPerSymbol, ...
                'DecimationFactor',         obj.DecimationFactor);

            obj.pCoarseFreqEstimator = comm.CoarseFrequencyCompensator( ...
                'Modulation',               'QPSK', ...
                'Algorithm',                 obj.CFCAlgorithm,...
                'SampleRate',                obj.SampleRate/obj.DecimationFactor);

            if strcmpi(obj.CFCAlgorithm,'FFT-Based')
                obj.pCoarseFreqEstimator.FrequencyResolution =     obj.FrequencyResolution;
            else
                obj.pCoarseFreqEstimator.MaximumFrequencyOffset =  obj.MaximumFrequencyOffset;
            end

            obj.pCoarseFreqCompensator = comm.PhaseFrequencyOffset( ...
                'PhaseOffset',              0, ...
                'FrequencyOffsetSource',    'Input port', ...
                'SampleRate',               obj.SampleRate/obj.DecimationFactor);

            obj.pMeanFreqOff = 0;

            obj.pCnt = 0;
%obj.PostFilterOversampling
            obj.pFineFreqCompensator = comm.CarrierSynchronizer( ...
                'Modulation',               'QPSK', ...
                'ModulationPhaseOffset',    'Auto', ...
                'SamplesPerSymbol',         1, ...
                'DampingFactor',            obj.PhaseRecoveryDampingFactor, ...
                'NormalizedLoopBandwidth',  obj.PhaseRecoveryLoopBandwidth);

            obj.pTimingRec = comm.SymbolSynchronizer( ...
                'TimingErrorDetector',      'Gardner (non-data-aided)', ...
                'SamplesPerSymbol',         obj.PostFilterOversampling, ...
                'DampingFactor',            obj.TimingRecoveryDampingFactor, ...
                'NormalizedLoopBandwidth',  obj.TimingRecoveryLoopBandwidth, ...
                'DetectorGain',             obj.TimingErrorDetectorGain);

            obj.pPrbDet = comm.PreambleDetector(obj.pModulatedHeader, ...
                'Input',                    'Symbol', ...
                'Threshold',                obj.PreambleDetectorThreshold);
                %'Detections',                 'First',...

            obj.pPrbDet2 = comm.PreambleDetector(obj.pHeader, ...
                'Input',                    'Symbol', ...
                'Threshold',                80);
                %'Detections',                 'First',...


                
            obj.pFrameSync = comm.internal.examples.FrameSynchronizer(  ...
                'OutputFrameLength',        obj.FrameSize, ...
                'PreambleLength',           obj.HeaderLength / 2);

            obj.pDataDecod = QPSKDataDecoder( ...
                'ModulationOrder',          obj.ModulationOrder, ...
                'HeaderLength',             obj.HeaderLength, ...
                'NumberOfMessage',          obj.NumberOfMessage, ...
                'PayloadLength',            obj.PayloadLength, ...
                'DescramblerBase',          obj.DescramblerBase, ...
                'DescramblerPolynomial',    obj.DescramblerPolynomial, ...
                'DescramblerInitialConditions', obj.DescramblerInitialConditions, ...
                'PrintOption',              obj.PrintOption);
        end

        function [RCRxSignal, AGCtimingRecSignal, fineCompSignal,phShiftedData,charSet,isFrameValid,prbIdx,dtMt,header,freqOffsetEst,PHEST,seqnum,flag] = stepImpl(obj, bufferSignal,state,freqOffsetnew)
            % AGCSignal = obj.pAGC(bufferSignal);                          % AGC control
            RCRxSignal = obj.pRxFilter(bufferSignal);                       % Pass the signal through

            % timingRecSignal = obj.pTimingRec(RCRxSignal);
            % AGCtimingRecSignal=obj.pAGC(timingRecSignal);
            % RCRxSignal = AGCSignal;
            % Square-Root Raised Cosine Received Filter


            if state==0
            freqOffsetEst=freqOffsetnew;   
            % [Coarsecomp, freqOffsetEst] =
            % obj.pCoarseFreqEstimator(RCRxSignal);   % Coarse frequency offset estimation
            % Coarsecomp = RCRxSignal;
            % freqOffsetEst = 0;

            % average coarse frequency offset estimate, so that carrier
            % sync is able to lock/converge
            % freqOffsetEst = (freqOffsetEst + obj.pCnt * obj.pMeanFreqOff)/(obj.pCnt+1);
            % obj.pCnt = obj.pCnt + 1;            % update state
            % obj.pMeanFreqOff = freqOffsetEst;

            coarseCompSignal = obj.pCoarseFreqCompensator(RCRxSignal,...
                -freqOffsetnew);                                         % Coarse frequency compensation

            % coarseCompSignal = Coarsecomp;
               


            %  [fineCompSignal,PHEST] = obj.pFineFreqCompensator(coarseCompSignal);  % Fine frequency compensation
            %  timingRecSignal = obj.pTimingRec(fineCompSignal);          % Symbol timing recovery
            % 
            %  % timingRecSignal = fineCompSignal;
            % 
            % [prbIdx, dtMt] = obj.pPrbDet(timingRecSignal);                % Detect frame header
            
            % 
            % 
            % 
            % % timingRecSym= pskdemod(timingRecSignal,4,pi/4,OutputType="bit",OutputDataType="double");
            % % timingRecSym= int16(bi2de(reshape(timingRecSym, 2, [])', 'left-msb'));
            % % timingRecSym = double(timingRecSym);
            % % [prbIdx, dtMt] = obj.pPrbDet2(timingRecSym); 
            % 
            % 
            % 
            % [symFrame, isFrameValid] = obj.pFrameSync(timingRecSignal, ...
            %     prbIdx, dtMt);                                           % Frame synchronization


            % timingRecSignal = obj.pTimingRec(coarseCompSignal);
            
            % [fineCompSignal,PHEST] = obj.pFineFreqCompensator(timingRecSignal);  % Fine frequency compensation
            
            % coarseCompSignal = RCRxSignal;
            % fineCompSignal = coarseCompSignal;
            
            else
            [coarseCompSignal, freqOffsetEst] = obj.pCoarseFreqEstimator(RCRxSignal);   % Coarse frequency offset estimation
            % coarseCompSignal = obj.pCoarseFreqCompensator(RCRxSignal,...
            %     -freqOffsetEst);
            % disp(freqOffsetEst);
            % timingRecSignal = obj.pTimingRec(coarseCompSignal);

            % [fineCompSignal,PHEST] = obj.pFineFreqCompensator(timingRecSignal);  % Fine frequency compensation
            % freqOffsetEst=0;
            % coarseCompSignal = RCRxSignal;
            % fineCompSignal = coarseCompSignal;

            end
            timingRecSignal = obj.pTimingRec(coarseCompSignal);
            AGCtimingRecSignal=obj.pAGC(timingRecSignal);
            % AGCtimingRecSignal=timingRecSignal;
            [fineCompSignal,PHEST] = obj.pFineFreqCompensator(AGCtimingRecSignal);
            [prbIdx, dtMt] = obj.pPrbDet(fineCompSignal);                % Detect frame header
            [symFrame, isFrameValid] = obj.pFrameSync(fineCompSignal, ...
                prbIdx, dtMt);                                           % Frame synchronization
            [phShiftedData ,charSet,header,seqnum,flag]= obj.pDataDecod(symFrame, isFrameValid);

            % PHEST=[];
            
         
         
        end

        function resetImpl(obj)
            reset(obj.pAGC);
            reset(obj.pRxFilter);
            reset(obj.pCoarseFreqEstimator);
            reset(obj.pCoarseFreqCompensator);
            reset(obj.pFineFreqCompensator);
            reset(obj.pTimingRec);
            reset(obj.pPrbDet);
            reset(obj.pPrbDet2);
            reset(obj.pFrameSync);
            reset(obj.pDataDecod);
            obj.pMeanFreqOff = 0;
            obj.pCnt = 0;
        end

        function releaseImpl(obj)
            release(obj.pAGC);
            release(obj.pRxFilter);
            release(obj.pCoarseFreqEstimator);
            release(obj.pCoarseFreqCompensator);
            release(obj.pFineFreqCompensator);
            release(obj.pTimingRec);
            release(obj.pPrbDet);
            release(obj.pPrbDet2);
            release(obj.pFrameSync);
            release(obj.pDataDecod);
        end

        function N = getNumOutputsImpl(~)
            N = 13;
        end
    end
end