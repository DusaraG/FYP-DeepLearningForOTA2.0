classdef QPSKDataDecoder < matlab.System
    properties (Nontunable)
        ModulationOrder; 
        HeaderLength;
        PayloadLength;
        NumberOfMessage;
        DescramblerBase;
        DescramblerPolynomial;
        DescramblerInitialConditions;
        PrintOption = false;
    end

    properties (Constant, Access = private)
        pBarkerCode = [+1; +1; +1; +1; +1; -1; -1; +1; +1; -1; +1; -1; +1]; % Bipolar Barker Code
    end
    
    properties (Access = private)
        pPayloadLength
        pQPSKDemodulator
        pQPSKDemodulator2
        pDescrambler
        pModulatedHeader = sqrt(2)/2 * (-1-1i) * QPSKDataDecoder.pBarkerCode;
    end
    
    methods
        function obj = QPSKDataDecoder(varargin)
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    methods (Access = protected)
        function setupImpl(obj, ~, ~)
            coder.extrinsic('sprintf');
            
            obj.pQPSKDemodulator = comm.QPSKDemodulator('PhaseOffset',pi/4, ...
                'BitOutput', true);


            obj.pQPSKDemodulator2 = comm.QPSKDemodulator('BitOutput', true);

            % 
            obj.pDescrambler = comm.Descrambler(obj.DescramblerBase, ...
                obj.DescramblerPolynomial, obj.DescramblerInitialConditions);


 
        end
        
        function  [phShiftedData,charSet,header,seqnum,flag] = stepImpl(obj, data, isValid)
            % charSet = [];
            % % phShiftedData = [];
            % header= [];
            
            if isValid
                % Phase ambiguity estimation
                phaseEst = round(angle(mean(conj(obj.pModulatedHeader) .* data(1:obj.HeaderLength/2)))*2/pi)/2*pi;
                
                % Compensating for the phase ambiguity
                % phShiftedData=data;
                phShiftedData = data .* exp(-1i*phaseEst);
                
                % Demodulating the phase recovered data
                % demodOut = obj.pQPSKDemodulator(phShiftedData(1:21));
           
                % demodOutdata = qamdemod(phShiftedData(22:end),16,OutputType='bit',UnitAveragePower=true);
                % demodOutdata   =   pskdemod(phShiftedData(22:end),4,pi/4,OutputType="bit",OutputDataType="double");
                %%%%%%
                % demodOutdata = obj.pQPSKDemodulator2(phShiftedData(22:end));


                demodOut   =   pskdemod(phShiftedData(1:21),4,pi/4,OutputType="bit",OutputDataType="double");
                
                % demodOutdata = pskdemod(phShiftedData(22:end),4,OutputType="bit",OutputDataType="double");


                % demodOut = [demodOut;demodOutdata];



                % Performs descrambling on only payload part
                % deScrData = obj.pDescrambler( ...
                %     demodOut(obj.HeaderLength + (1 : obj.PayloadLength)));

                % deScrData = demodOut(obj.HeaderLength + (1 : obj.PayloadLength));

                header = demodOut(1:obj.HeaderLength );
                header = int16(bi2de(reshape(header, 2, [])', 'left-msb'));

                % charSet = int16(bi2de(reshape(demodOutdata, 2, [])', 'left-msb'));
                
                seqnum= int16(bi2de(reshape(demodOut(obj.HeaderLength+1:end-4),12, [])', 'left-msb'));
                flag = int16(bi2de(reshape(demodOut(obj.HeaderLength+13:end),4, [])', 'left-msb'));
                charSet = [int16(seqnum)];
                % Recovering the message from the data
                current_timestamp = datetime('now', 'Format', 'yyyy-MM-dd HH:mm:ss.SSS');
                if(obj.PrintOption)
                    
                    fprintf('%s %s\n',num2str(seqnum),"seuqence Received");
                end
            else
                seqnum=int16(0);
                flag = int16(16);
                header = int16([10;10;10;10;10;10;10;10;10;10;10;10;10]);
                charSet = int16(ones(obj.NumberOfMessage,1));
                phShiftedData =repmat(0+1e-10i,5613,1);
            end
        end
        
        function resetImpl(obj)
            reset(obj.pQPSKDemodulator);
            reset(obj.pDescrambler);
            
        end
        
        function releaseImpl(obj)
            release(obj.pQPSKDemodulator);
            release(obj.pDescrambler);
            
        end
    end
end

