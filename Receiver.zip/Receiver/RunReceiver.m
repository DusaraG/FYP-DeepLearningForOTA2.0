function rxsignal = RunReceiver(config, Isprint, Th)

rxsignal = runRx(config.rrc, Isprint, Th);

%lgraph = layerGraph(net);
%plot(lgraph)




