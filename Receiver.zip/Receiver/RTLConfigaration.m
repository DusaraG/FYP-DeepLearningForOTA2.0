function rx = RTLConfiguration(RTLSampleRate, RTLCenterFrequency, RTLGain)
%%  Creating radio object

SamplesPerFrame = 250000;
Time = 70;
isReceived = false;
rx.radio = comm.SDRRTLReceiver('0','CenterFrequency',RTLCenterFrequency,'SampleRate',RTLSampleRate, ...
    'SamplesPerFrame',SamplesPerFrame,'EnableTunerAGC',true,'OutputDataType','double');

%% pilot

rx.pilot      = [+1 +1 +1 +1 +1 -1 -1 +1 +1 -1 +1 -1 +1];
rx.pilot = rx.pilot + 1j * rx.pilot; 

cd('C:\Users\HP\Desktop\demo\RealTime\Receiver\rxModels');
rx.param = load("nn_param.mat");
cd('C:\Users\HP\Desktop\demo\RealTime\Receiver');

%% %% RRC RX Filter parameters

rx.rrcRollOff = 0.35;
rx.rrcNumTaps = 31;
rx.rrcOutputSamplesPerSymbol = 4;
rx.DecimationFactor = 4;
rx.rrcTxsize = 640;
rx.framesize = 5592;

rx.rrc = rrcRx_init(RTLSampleRate/2, RTLCenterFrequency, RTLGain, Time, isReceived, rx.param.k, rx.param.n);




