% Evaluate on test set
YPred = classify(model, test_ds);
YTest = testLabels; % Your ground truth labels

accuracy = mean(YPred == YTest);
fprintf('Test Accuracy: %.2f%%\n', accuracy * 100);
