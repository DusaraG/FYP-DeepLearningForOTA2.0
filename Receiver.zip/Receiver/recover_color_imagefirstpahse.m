% Assuming 'frames' contains your frames
dimentions=3;
imageframecount = ceil((640*360*dimentions*8*(n/2))/(5592*k));

imageframecount=ceil(imageframecount);
% Concatenate frames into a single binary stream
reconstructedBinaryString = '';
rximageframes=mesrxdecodeNN;
imageframenums = rximageframes(end,:);
rximageframes=rximageframes(1:end-1,:);
messagesperframe = (5592/(n/2));

for i = 1:imageframecount
    frameindex=find(imageframenums==(i+10));
    if  isempty(frameindex)
        imageframe = zeros((5592/(n/2)),1);
    else
        imageframe=rximageframes(:,frameindex);
    end
    imageframebinary=de2bi(imageframe,k,'left-msb');
    imageframebinary1=imageframebinary';
    imageframebinary2=imageframebinary1(:);
    imageframebinary3=num2str(imageframebinary2);
    imageframebinary4=sprintf('%s', imageframebinary3);


    reconstructedBinaryString = [reconstructedBinaryString, imageframebinary4];
end
imagebitsize=360*640*8*3;
reconstructedBinaryString=reconstructedBinaryString(1:imagebitsize);

% Convert binary string to pixel values
numPixels = numel(reconstructedBinaryString) / 8;
pixelValues = zeros(1, numPixels);
for i = 1:numPixels
    startIndex = (i - 1) * 8 + 1;
    endIndex = i * 8;
    pixelValues(i) = bin2dec(reconstructedBinaryString(startIndex:endIndex));
end

% Reshape pixel values into image matrix
 reconstructedTensor = reshape(pixelValues, [3,360, 640]);
reconstructedImage =  permute(reconstructedTensor,[2,3,1]);
% Display the reconstructed image
% imshow(uint8(reconstructedImage));