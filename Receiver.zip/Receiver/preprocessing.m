classdef preprocessing < nnet.layer.Layer

  properties
       rollOff = 0.35;
       numTaps = 31;
       timeDelay = 0;
       r = 4; % Upsampling factor
       ts = 1; % Sampling period
       rrcFilter
       txSize
       
  end
  
  methods
    function layer = preprocessing(varargin)
      p = inputParser;
      addParameter(p,'rollOff',0.35)
      addParameter(p,'numTaps',31)
      addParameter(p,'timeDelay',0)
      addParameter(p,'r',4)
      addParameter(p,'ts',1)
      addParameter(p,'Name','StochasticChannelv4')
      addParameter(p,'Description','')
      addParameter(p,'txSize',128)
      
      parse(p,varargin{:})

      layer.rollOff = p.Results.rollOff;
      layer.numTaps = p.Results.numTaps;
      layer.timeDelay = p.Results.timeDelay;
      layer.r = p.Results.r;
      layer.ts = p.Results.ts;
      layer.Name = p.Results.Name;
      layer.txSize = p.Results.txSize;

      if isempty(p.Results.Description)
        layer.Description = "preprocessing";
      else
        layer.Description = p.Results.Description;
      end

    % Create RRC transmit filter
      layer.rrcFilter = comm.RaisedCosineTransmitFilter(...
    'RolloffFactor', layer.rollOff, ...
    'FilterSpanInSymbols', ceil(layer.numTaps/2), ...
    'OutputSamplesPerSymbol', layer.r);
      
    end

        
        % Upsample and Filter
    function signal = upsampleAndFilter(layer, upsampled_signal) %signal)

        real_filtered = zeros(size(upsampled_signal,1)*layer.r,1,1,size(upsampled_signal,4));
        imag_filtered = zeros(size(upsampled_signal,1)*layer.r,1,1,size(upsampled_signal,4));
        for i=1:size(upsampled_signal,4)
            release(layer.rrcFilter);
            real_filtered(:, 1, :,i) = layer.rrcFilter(upsampled_signal(:, 1, :,i));
            %release(layer.rrcFilter);
            imag_filtered(:, 1, :,i) = layer.rrcFilter(upsampled_signal(:, 2, :,i));
            
        end
        real_filtered = reshape(real_filtered,size(real_filtered,1),1,1,[]);
        imag_filtered = reshape(imag_filtered,size(imag_filtered,1),1,1,[]);
    
    
        signal = complex(real_filtered,imag_filtered);
        
        
     end
        
        
        % Forward pass
     function outputs = predict(layer, inputs)
        %display(inputs)
        %batchSize = size(inputs, 2)*size(inputs, 4);
        numFeatures = (size(inputs, 1)/2); % Assuming input has real and imaginary parts
        %batches = size(inputs, 4);
        

            
        % Reshape input to separate real and imaginary parts
        inputs = reshape(inputs,numFeatures, 2, layer.txSize,[]);
        % Define a function to process each sample
        process_sample = @(sample) layer.upsampleAndFilter(sample);  % Process each sample
            
         % Apply the function to each sample in the batch
        output = arrayfun(@(i) process_sample(inputs(:, :, i,:)), 1:layer.txSize, 'UniformOutput', false);
        
        output = cat(3, output{:});
        
        %outputs = reshape(output, [],batches);
        %outputs = reshape(outputs,[],1);
        

%         if mod(size(outputs,1),48) ~= 0
%             zeros_vect = zeros(32-mod(size(outputs,1),48),1);
%             outputs = [outputs,zeros_vect];
%         end
        outputs = reshape(output,size(output,1)*layer.txSize,1,[]);
        %p_data2 = reshape(p_data,size(p_data,1)*672,1,[])
        outputs=single(outputs);

        
     end


     function config = getConfig(layer)
       config = struct();
       config.Name = layer.Name;
       config.Description = layer.Description;
    end

  end
end