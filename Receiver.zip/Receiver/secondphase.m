  M = 2^2;

trainParams.InitialLearnRate = 0.08;

    trainParams.MaxEpochs = 10;
  trainParams.MiniBatchSize = 100*M;
   trainParams.LearnRateSchedule = 'piecewise';
  trainParams.LearnRateDropPeriod = 5;
  trainParams.LearnRateDropFactor = 0.1;
  trainParams.ExecutionEnvironment = 'cpu';
  trainParams.Plots = 'none'; %'training-progress';
  trainParams.Verbose = false;


 % explicitly appeneded for secnd phase
trainParams.secPhase_InitialLearnRate  = 0.5 * trainParams.InitialLearnRate;
trainParams.secPhase_Plots = 'training-progress';

% second phase of training
tic

% loadings
disp("loadings started");
actualLabels = load('actual_labels_signal.mat').actualLabels;
%actualLabels = load('actual_labels_signal.mat').actualLables;
received_signal = load('overTheAir_received_signal.mat').all_receivedFeatures;
rxNet = load('r3ki3g_saved_rx_all_layer_parameters.mat').rxNet;
thisRxNet = rxNet(1);
disp("loadings complete");


%setting : train set val set 
disp("train/val splitting  started");
n_totalExamples = length(actualLabels);
VAL_SPLIT_RATIO = 0.3;

randomizedIndices = randperm(n_totalExamples);
val_indices = randomizedIndices(1:VAL_SPLIT_RATIO*n_totalExamples);
train_indices = randomizedIndices(VAL_SPLIT_RATIO*n_totalExamples+1:end);

x2_all = reshape(received_signal',[],n); % need to transpose
x2_train = x2_all(train_indices,:);
y2_train = actualLabels(train_indices);
x2_val = x2_all(val_indices,:);
y2_val = actualLabels(val_indices);
disp("train/val splitting  ended");

% second pahse : Set training options
secPhase_options = trainingOptions('adam', ...
  'InitialLearnRate',trainParams.secPhase_InitialLearnRate, ...
  'MaxEpochs',trainParams.MaxEpochs, ...
  'MiniBatchSize',trainParams.MiniBatchSize, ...
  'Shuffle','every-epoch', ...
  'ValidationData',{x2_val,y2_val}, ...
  'LearnRateSchedule', trainParams.LearnRateSchedule, ...
  'LearnRateDropPeriod', trainParams.LearnRateDropPeriod, ...
  'LearnRateDropFactor', trainParams.LearnRateDropFactor, ...
  'ExecutionEnvironment', trainParams.ExecutionEnvironment, ...
  'Plots', trainParams.secPhase_Plots, ...
  'Verbose', trainParams.Verbose);


disp("sec phase training started");
maxIter = 10;
done = false;
iterCnt = 0;
while ~done
  % Train the autoencoder network
  [secPhase_trainedRxNet,secPhase_info] = trainNetwork(x2_train,y2_train,thisRxNet.Layers,secPhase_options);

  iterCnt = iterCnt + 1;
  % Check if the network converged or maximum iteration reached
  if (secPhase_info.FinalValidationAccuracy > 80) || (iterCnt >= maxIter)
    done = true;
  end
end


disp("sec phase training ended");
secPhase_fullTime = toc




