clear all;
n = 1;                      % number of channel uses
k = 4;% number of input bits
EbNo = 3; % dB

n = 2*n;%*********************edited               
normalization = "Average power";   % Normalization "Energy" | "Average power"

[txNet(1),rxNet(1),infoTemp,wirelessAutoEncoder(1)] = ...
  helperAEWTrainWirelessAutoencoder(n,k,normalization,EbNo);

infoTemp.n = n;
infoTemp.k = k;
infoTemp.EbNo = EbNo;
infoTemp.Normalization = normalization;
info = infoTemp;
myR3ki3gTrainingToc= toc;

save('r3ki3g_saved_rx_all_layer_parameters.mat',"rxNet");
filename = sprintf('nn%d_db%d_n%d_k%d.mat', EbNo, n, k);
save(filename); % Saving the file with the dynamically generated filename


% nnsym=de2bi([0:1:2^k-1],k,'left-msb')';
% nnsym1=nnsym(:);
% nnsym = helperAEWEncode(nnsym,txNet(1));
% scatterplot(nnsym);


QPSKTransmitterWithUSRPHardwareExample