load("nn3_db4_n2_k.mat")
% Read the original image
originalImage = imread('C:\Users\ASUS\OneDrive - University of Moratuwa\Pictures\Camera Roll\WIN_20240419_16_01_56_Pro.jpg'); % Replace 'dog.jpg' with the path to your image
% Resize the image to 240x240 and convert it to grayscale
resizedGrayImage = imresize(rgb2gray(originalImage), [360, 640]);
% Scale the intensity values to the range [0, 255] and convert to uint8
scaledImage = uint8(255 * mat2gray(resizedGrayImage));
flattenimage=scaledImage(:)';
% Display the resized and grayscale image
imshow(scaledImage);
% Convert the image matrix to a binary stream directly
binaryStream = de2bi(flattenimage, 8,'left-msb')'; % 8 bits per pixel
fatterbinary = binaryStream(:);
% Concatenate binary values into a single string

% Parameters for framing

framesize = 5592;
bitframesize = (framesize / (n/2)) * (k);
% Calculate the number of frames needed
numFrames = ceil(length(fatterbinary) / bitframesize);
% Divide binary string into frames
frames =[];
for i = 1:numFrames
    startIndex = (i - 1) * bitframesize + 1;
    endIndex = min(i * bitframesize, length(fatterbinary));
    frame=fatterbinary(startIndex:endIndex);
    diff=bitframesize-length(frame);
    frames = [frames,[frame;zeros(diff,1)]];
end
frames = [frames,zeros(bitframesize,1)];
numFrames=numFrames+1;

frames=double(frames);
% Display the number of frames
disp(['Number of frames: ', num2str(numFrames)]);


connectedRadios = findsdru;

if strncmp(connectedRadios(1).Status, 'Success', 7)
  platform = connectedRadios(1).Platform;
  switch connectedRadios(1).Platform
    case {'B200','B210'}
      address = connectedRadios(1).SerialNum;
    case {'N200/N210/USRP2','X300','X310','N300','N310','N320/N321'}
      address = connectedRadios(1).IPAddress;
  end
else
  address = '192.168.10.2';
  platform = 'N200/N210/USRP2';
end

USRPGain            = 30;  % Set USRP radio gain
USRPCenterFrequency = 1600000000;  % Set USRP radio center frequency
stopTime            = 15;  % USRP radio transmit time in seconds
symbolRate          = 125000;  % Sample rate of transmitted signal

% Transmitter parameter structure
prmQPSKTransmitter = sdruqpsktransmitter_init(platform, address, symbolRate, USRPCenterFrequency, ...
    USRPGain, stopTime,k,n);



underruns = runSDRuQPSKTransmitter(prmQPSKTransmitter,txNet(1),frames,numFrames);


fprintf('Total number of underruns = %d.\n', underruns);





















