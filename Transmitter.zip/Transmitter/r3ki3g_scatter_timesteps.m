time_step1_x = [1, 2, 3, 4];
time_step1_y = [2, 3, 4, 5];

time_step2_x = [2, 3, 4, 5];
time_step2_y = [3, 4, 5, 6];

% Create a new figure
figure;

% Plot points from the first time step
scatter(time_step1_x, time_step1_y, 'filled', 'DisplayName', 'Time Step 1');
hold on; % Hold the current plot so that subsequent plots are overlaid

% Plot points from the second time step
scatter(time_step2_x, time_step2_y, 'filled', 'DisplayName', 'Time Step 2');