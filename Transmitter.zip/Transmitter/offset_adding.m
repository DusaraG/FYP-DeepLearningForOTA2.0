classdef offset_adding < nnet.layer.Layer
    
    methods
        function layer = offset_adding(varargin)
            % Constructor for SD_RNN custom layer
              p = inputParser;
              addParameter(p,'Name','offset_adding')
              addParameter(p,'Description','')
              
              parse(p,varargin{:})
              
              layer.Name = p.Results.Name;
        
              if isempty(p.Results.Description)
                layer.Description = "offset_adding";
              else
                layer.Description = p.Results.Description;
              end
      
            
           
        end
        
        function output = predict(layer, X)
            % Get the input dimension
            random = randn(size(X))*2*pi;
            output = X.*random;
    
            %display(X)
            %display(output)

        end


        function [dLdX] = backward(layer, X,~, dLdY,~) 

            dLdX = dLdY; 
            
        end
     end
end