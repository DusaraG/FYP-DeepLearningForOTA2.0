function objects = USRPConfigaration(platform, address, USRPcenterFrequency, USRPGain, USRPSampleRate)
%% Creating radio object

masterclockRate = 1e8;
interpolationFactor = masterclockRate/USRPSampleRate;

objects.radio = comm.SDRuTransmitter(...
                    'Platform',             platform, ...
                    'IPAddress',            address, ...
                    'CenterFrequency',      USRPcenterFrequency, ...
                    'Gain',                 USRPGain, ...
                    'InterpolationFactor',  interpolationFactor);



%% pilot code parameters
objects.pilot      = [+1 +1 +1 +1 +1 -1 -1 +1 +1 -1 +1 -1 +1];

cd('C:\Users\HP\Desktop\demo\RealTime\Transmitter\tx_layers');
objects.param = load("nn_param.mat");
cd('C:\Users\HP\Desktop\demo\RealTime\Transmitter');

%% RRC Filter parameters

objects.rrcRollOff = 0.35;
objects.rrcNumTaps = 31;
objects.rrcOutputSamplesPerSymbol = 4;
objects.rrcTxsize = 640;
objects.framesize = 5592;


objects.rrc = rrc_init(platform, address, USRPSampleRate/2, USRPcenterFrequency,USRPGain, 100,objects.param.k,objects.param.n);



