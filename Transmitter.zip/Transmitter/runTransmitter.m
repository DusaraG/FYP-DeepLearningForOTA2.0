function tx = runTransmitter(txData,frames,config)

radio = config.radio;
pilot = config.pilot;
pilot_cmpx = pilot + 1j*pilot;
p_data = frames.data_in;
frame_im = frames.frames;
release(radio);
underruns=0;

for j = 1:size(p_data,1)
   
    preambled_data = [pilot_cmpx;p_data(j)];
    %display("frame transmitted, no. of underruns :"+num2str(underruns));
    %pause(1);
end

runSDRTx(config.rrc,config.param.txNet(1),frame_im,frames.numFrames);




