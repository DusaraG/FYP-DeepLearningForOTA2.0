pBarkerCode = [+1 +1 +1 +1 +1 -1 -1 +1 +1 -1 +1 -1 +1];
ubc = ((pBarkerCode + 1) / 2)';
            temp = (repmat(ubc,1,2))';
            pHeader = temp(:);

seqnum = 1;
 data = randi([0 , 3],5593,1);
            bits = de2bi(data, 2, 'left-msb')';
            msgBin = bits(:);
            seqNUmbin = de2bi(seqnum, 2*7, 'left-msb')';
            msgBin=[msgBin;seqNUmbin];
            % Scramble the data
            % scrambledMsg = pScrambler(msgBin);
            scrambledMsg = msgBin;
            % Append the scrambled bit sequence to the header
            y = [pHeader ; scrambledMsg];

transmittedBin = y;
 
header = pskmod(transmittedBin(1:26,:),4,pi/4,InputType="bit",OutputDataType="double");        % Modulates the bits into QPSK symbols    
            modulatedData = helperAEWEncode(transmittedBin(27:end-14,:),txNet);
            seqnum= pskmod(transmittedBin(end-14+1:end,:),4,pi/4,InputType="bit",OutputDataType="double");
            modulatedData = [header;modulatedData;seqnum];