function frameOut = preproce(img,height, width, configData)

resizedImage = imresize(img, [height, width]);
imshow(resizedImage);

img1D = resizedImage(:); 
frameOut.data_in = num2cell(img1D);
permuted = permute(resizedImage,[3,1,2]);
flattenimage=uint8(permuted(:)');
binaryStream = de2bi(flattenimage, 8,'left-msb')';
fatterbinary = binaryStream(:);

framesize = configData.framesize;
n = configData.param.n;
k = configData.param.k;
bitframesize = (framesize / (n/2)) * (k);
% Calculate the number of frames needed
numFrames = ceil(length(fatterbinary) / bitframesize);
% Divide binary string into frames
frames =[];

for i = 1:numFrames
    startIndex = (i - 1) * bitframesize + 1;
    endIndex = min(i * bitframesize, length(fatterbinary));
    frame=fatterbinary(startIndex:endIndex);
    diff=bitframesize-length(frame);
    frames = [frames,[frame;zeros(diff,1)]];
end

frames = [frames,zeros(bitframesize,1)];
frameOut.numFrames=numFrames+1;

frameOut.frames=double(frames);