function encoding_data = encoding_data(txNet,frames)
    txData = predict(txNet, frames.data_in);
    
    batchSize = 128;

    if size(txData{end},2) <batchSize
        txData{end} = [cell2mat(txData(end)),zeros(size(txData{end},1),batchSize-size(txData{end},2))],size(txData{1},1),size(txData{1},2);
    end

    encoding_data.txData = cat(4, txData{:});

    preprocesseSignals = preprocessing('Name', 'preprocessing', 'txSize',1);
    %encoding_data.process_data = preprocesseSignals.predict(txData);

    lgraph = layerGraph(txNet);
    display("Encoder network");
    plot(lgraph);

