function underrun = runSDRuQPSKTransmitter(prmQPSKTransmitter,txnet,frames,numFrames)

    persistent hTx radio
    if isempty(hTx)
        % Initialize the components
        % Create and configure the transmitter System object
        hTx = QPSKTransmitter(...
            'UpsamplingFactor',             prmQPSKTransmitter.Interpolation, ...
            'RolloffFactor',                prmQPSKTransmitter.RolloffFactor, ...
            'RaisedCosineFilterSpan',       prmQPSKTransmitter.RaisedCosineFilterSpan, ...
            'MessageLength',                prmQPSKTransmitter.MessageLength, ...
            'NumberOfMessage',              prmQPSKTransmitter.NumberOfMessage, ...
            'ScramblerBase',                prmQPSKTransmitter.ScramblerBase, ...
            'ScramblerPolynomial',          prmQPSKTransmitter.ScramblerPolynomial, ...
            'ModulationOrder',              prmQPSKTransmitter.ModulationOrder,...
            'txnet',                        txnet,...
            'ScramblerInitialConditions',   prmQPSKTransmitter.ScramblerInitialConditions);
        
        % Create and configure the SDRu System object. 
        
          radio = comm.SDRuTransmitter(...
                    'Platform',             prmQPSKTransmitter.Platform, ...
                    'IPAddress',            prmQPSKTransmitter.Address, ...
                    'CenterFrequency',      prmQPSKTransmitter.USRPCenterFrequency, ...
                    'Gain',                 prmQPSKTransmitter.USRPGain, ...
                    'InterpolationFactor',  prmQPSKTransmitter.USRPInterpolationFactor);
       

            
    end    
    
    cleanupTx = onCleanup(@()release(hTx));
    cleanupRadio = onCleanup(@()release(radio));

    currentTime = 0;
    underrun = uint32(0);

    moddata=[];
    mesdata=[];
    txdata=[];
    seqnumqpsk=1;
    seqnumdata=11;
    
    %Transmission Process
    disp("started")
    display(num2str(1)+" frame transmitted, no. of underruns :"+num2str(underrun));

    while currentTime < prmQPSKTransmitter.StopTime
        % Bit generation, modulation and transmission filtering

        if seqnumqpsk<11
            [data,~]=QpskFrameGen(seqnumqpsk);
            seqnumqpsk=seqnumqpsk+1;
            txdata = [txdata,data];
        else
            
            [modulatedData,data] = hTx(seqnumdata,frames);
            seqnumdata=seqnumdata+1;
            if (rem(seqnumdata-11,100))==0
                seqnumqpsk=1;
            end
            moddata=[moddata,modulatedData];
            txdata=[txdata,data];
        end

        % Data transmission
        tunderrun = radio(double(data));
        underrun = underrun + tunderrun;
        if (rem(abs(seqnumdata-11),100)) ~=0
            display(num2str(seqnumdata)+" frame transmitted, no. of underruns :"+num2str(underrun));
        end
        if (rem(abs(seqnumdata-11),100)) ==0
            display(num2str(floor(abs(seqnumdata-11)/100)*100+seqnumqpsk)+" frame transmitted, no. of underruns :"+num2str(underrun));
        end
        % Update simulation time
        currentTime=currentTime+prmQPSKTransmitter.USRPFrameTime;
        if seqnumdata==numFrames+10+1
            %disp("r3ki3g broke while loop");
            break;
        end
        
    end
   disp("Finished");
    % save('mesdata.mat','mesdata');
    save('txdata.mat','txdata');
    save('moddata.mat','moddata');
    cd('C:\Users\HP\Desktop\demo\RealTime\Transmitter');

    % moddata = reshape(moddata,[],1);
    % scatterplot(moddata);

end